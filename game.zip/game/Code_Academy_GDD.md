# Game Design Document (GDD)

# Code Academy

### "Become the Programmer Who Saves the School"

## 1. Gambaran Umum

-   **Genre:** Adventure • Puzzle • Educational • RPG Lite
-   **Platform:** Website (HTML, CSS, JavaScript)
-   **Target:** Siswa kelas X PPLG
-   **Durasi:** 5--10 menit

## 2. Cerita

Pemain adalah siswa baru di **Code Academy**. Saat orientasi dimulai,
seluruh sistem sekolah diserang **Bug King**. Setiap ruangan sekolah
rusak dan hanya bisa diperbaiki menggunakan logika pemrograman.

## 3. Gameplay Flow

``` text
Opening
↓
Intro Story
↓
Character Selection
↓
Tutorial
↓
Explore Academy
↓
Mission
↓
Mini Games
↓
Boss Battle
↓
Score
↓
Badge
↓
Certificate
```

## 4. Dunia

                   SERVER ROOM
                        ▲
                        │
    LIBRARY ◄── PLAYER ─► LAB AI
                        │
                        ▼
                  DEBUG ARENA

Pemain bergerak dengan WASD atau Arrow Keys.

## 5. Character Creator

-   Rambut
-   Hoodie
-   Warna pakaian
-   Nama karakter

## 6. UI

### Atas

-   ❤️ Nyawa
-   ⭐ Skor
-   📍 Misi
-   ⏱ Waktu

### Bawah

-   Inventory
-   Hint
-   Map
-   Settings

## 7. Sistem Skor

-   Benar: +100
-   Combo: +150
-   Perfect: +250
-   Hint: -20
-   Maksimum: 1000

## 8. Level

### Level 1 - Welcome Programmer

Kenalan dengan sekolah dan NPC.

### Level 2 - Variable Room

Drag & drop data ke kotak variabel.

### Level 3 - Input Output

Cocokkan input dengan output.

### Level 4 - If Else

Pilih keputusan yang benar untuk membuka pintu.

### Level 5 - Loop Factory

Gunakan Repeat 5x untuk membantu robot.

### Level 6 - Debug Room

Temukan bug pada potongan kode bergambar.

### Level 7 - Function Machine

Susun urutan Start → Input → Process → Output → End.

### Level 8 - Boss Battle

Lawan Bug King. Jawaban benar mengurangi HP boss.

## 9. Achievement

-   Bug Hunter
-   Logic Master
-   Speed Runner
-   Perfect Run
-   Coding Hero

## 10. Badge

-   🏆 Coding Master (950+)
-   🥇 Logic Hero (850+)
-   🥈 Future Programmer (700+)
-   🥉 Explorer (500+)
-   📘 Beginner (\<500)

## 11. Ending

Tampilkan: - Total skor - Akurasi - Waktu - Badge - Achievement

Lalu berikan sertifikat digital yang bisa diunduh.

## 12. Visual

-   Pixel Art Modern
-   Warna biru, ungu, cyan
-   Animasi glow
-   Particle effect
-   Screen shake saat boss

## 13. Audio

-   Musik menu
-   Musik boss
-   Efek jawaban benar/salah
-   Victory theme

## 14. Teknologi

-   HTML
-   CSS
-   JavaScript
-   LocalStorage
-   requestAnimationFrame()

## 15. Struktur Folder

``` text
CodeAcademy/
├── assets/
├── css/
├── js/
├── pages/
├── certificate/
└── index.html
```

## 16. Estimasi Durasi

Total permainan sekitar **7--9 menit**.

## 17. Tujuan Edukasi

Pemain mempelajari: - Variabel - Input & Output - If Else - Loop -
Function - Debugging - Computational Thinking

Semua dikemas dalam bentuk petualangan interaktif, bukan kuis biasa.
